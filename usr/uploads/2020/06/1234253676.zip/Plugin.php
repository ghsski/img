<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * 设置博客建立及已运行时间
 * 
 * @package  Zcstime
 * @author Inkedus
 * @version 1.0.0
 * @link http://zhuchunshu.com
 */
class Zcstime_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     */
    public static function activate()
    {
        Typecho_Plugin::factory('zcsbqy')->zcstime =  array('Zcstime_Plugin','zcstime'); 
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     */
    public static function deactivate(){
        return _t("禁用成功");
    }
    
    /**
     * 获取插件配置面板
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        /** 分类名称 */
        $time = new Typecho_Widget_Helper_Form_Element_Text('time', null, date("Y-m-d H:i:s") , _t('网站建立时间'), '设置网站建立时间,格式: 2020-06-22 01:02:00');
        $form->addInput($time);
        $var3 = new Typecho_Widget_Helper_Form_Element_Select('var3',array('0'=>'不显示','1'=>'显示'),'1','是否显示网站建立时间','默认显示');
        $form->addInput($var3);
        $var1 = new Typecho_Widget_Helper_Form_Element_Select('var1',array('0'=>'不显示','1'=>'显示'),'0','是否显示网站已运行时间','默认不显示');
        $form->addInput($var1);
        $var2 = new Typecho_Widget_Helper_Form_Element_Select('var2',array('0'=>'不启用','1'=>'启用'),'1','显示网站已运行时间是否启用独立代码','默认不启用,如果选择启用,请把&lt;?php Typecho_Plugin::factory("zcsbqy")->zcstimes(); ?&gt;插入到你需要让它展示的位置');
        $form->addInput($var2);
    }
    
    /**
     * 个人用户的配置面板
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 插件实现方法
     */
    public static function zcstime()
    {
        $time = Helper::options()->plugin('Zcstime')->time;
        $var1=Helper::options()->plugin('Zcstime')->var1;
        $var2=Helper::options()->plugin('Zcstime')->var2;
        $var3=Helper::options()->plugin('Zcstime')->var3;
        if ($var3=="1") {
            # 显示网站建设时间
            if ($var1=="0") {
                # 不显示运行时间
                echo "本站建设于$time";
            }else{
                #显示运行时间
                if ($var2=="0") {
                    # 不启用独立代码
                    echo "本站建设于$time.已勉强运行".$datecheck=self::datecheck($time,date("Y-m-d H:i:s"));
                }else{
                    # 启用独立代码
                    echo "本站建设于$time";
                    Typecho_Plugin::factory('zcsbqy')->zcstimes =  array('Zcstime_Plugin','zcsdulicode'); 
                }
            }
        }else{
            # 不显示网站建设时间
            if ($var1=="0") {
                # 不显示运行时间
            }else{
                #显示运行时间
                if ($var2=="0") {
                    # 不启用独立代码
                    echo "本站已勉强运行".$datecheck=self::datecheck($time,date("Y-m-d H:i:s"));
                }else{
                    # 启用独立代码
                    echo "本站";
                    Typecho_Plugin::factory('zcsbqy')->zcstimes =  array('Zcstime_Plugin','zcsdulicode'); 
                }
            }
        }
    }
    public static function datecheck($dingyidate,$dangqiandate){
        $date1 = strtotime($dingyidate);  
        $date2 = strtotime($dangqiandate); 
        $diff = abs($date2 - $date1);  
        //转换时间差的格式
        $years = floor($diff / (365*60*60*24)); 
        $months = floor(($diff - $years * 365*60*60*24)  / (30*60*60*24));
        $days = floor(($diff - $years * 365*60*60*24 -  $months*30*60*60*24)/ (60*60*24)); 
        $hours = floor(($diff - $years * 365*60*60*24   - $months*30*60*60*24 - $days*60*60*24)  / (60*60));
        $minutes = floor(($diff - $years * 365*60*60*24  - $months*30*60*60*24 - $days*60*60*24  - $hours*60*60)/ 60); 
        $seconds = floor(($diff - $years * 365*60*60*24  - $months*30*60*60*24 - $days*60*60*24  - $hours*60*60 - $minutes*60)); 
        if ($years=="0") {
            if ($months=="0") {
                if ($days=="0") {
                    if ($hours=="0") {
                        return("$minutes 分, $seconds 秒");  
                    }else{
                        return("$hours 时, $minutes 分, $seconds 秒");  
                    }
                }else{
                    return("$days 日, $hours 时, $minutes 分, $seconds 秒");  
                }
            }else{
                return("$months 月, $days 日, $hours 时, $minutes 分, $seconds 秒");  
            }
        }else{
            return("$years 年,$months 月, $days 日, $hours 时, $minutes 分, $seconds 秒");  
        }
    }
    public static function zcsdulicode(){
        $time = Helper::options()->plugin('Zcstime')->time;
        $var1=Helper::options()->plugin('Zcstime')->var1;
        $var2=Helper::options()->plugin('Zcstime')->var2;
        if ($var2=="0") {
            # 不启用独立代码
        }else{
            # 启用独立代码
            echo ".已勉强运行".$datecheck=self::datecheck($time,date("Y-m-d H:i:s"));
        }
    }
}

